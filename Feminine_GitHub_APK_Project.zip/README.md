# Feminine 🎀
تطبيق هوايات يدوية كيوت وبناتي.

## بناء APK
ارفعي المشروع إلى GitHub، ثم افتحي Actions وشغّلي **Build Feminine APK**. بعد نجاح البناء، حمّلي artifact باسم `feminine-apk`.
