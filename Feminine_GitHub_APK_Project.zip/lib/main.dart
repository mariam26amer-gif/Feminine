import 'package:flutter/material.dart';

void main() => runApp(const FeminineApp());

class FeminineApp extends StatelessWidget {
  const FeminineApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Feminine',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFFF8FC),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFD85B91)),
        fontFamily: 'sans',
      ),
      home: const WelcomePage(),
    );
  }
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🎀', style: TextStyle(fontSize: 72)),
            const Text('Feminine', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w800, color: Color(0xFFD85B91))),
            const SizedBox(height: 8),
            const Text('Small steps, Big skills', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('اتعلمي هوايات وحرف يدوية من البيت، خطوة بخطوة وبطريقة ممتعة 💕', textAlign: TextAlign.center, style: TextStyle(height: 1.6)),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage())),
              child: const Padding(padding: EdgeInsets.symmetric(horizontal: 28, vertical: 12), child: Text('ابدئي الآن ✨')),
            )
          ],
        ),
      ),
    ),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [HomeTab(), FavoritesTab(), ProfileTab()];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Feminine 🎀', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFFD85B91))),
      backgroundColor: Colors.transparent,
    ),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
      ],
    ),
  );
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('أهلًا بيكي 💕', style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      const Text('اختاري هواية جديدة تتعلميها النهارده', style: TextStyle(color: Color(0xFF947184))),
      const SizedBox(height: 20),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12, crossAxisSpacing: 12,
        children: const [
          Cat('🧶', 'كروشيه', Color(0xFFFFE4EF)),
          Cat('🎨', 'رسم', Color(0xFFEEE5FF)),
          Cat('🪡', 'تطريز', Color(0xFFFFF2C9)),
          Cat('💍', 'إكسسوارات', Color(0xFFE2F4E9)),
        ],
      ),
      const SizedBox(height: 18),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('كمّلي اللي بدأتيه 🌷', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Text('🐰  كروشيه أرنب كيوت'),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: .35, color: const Color(0xFFD85B91), backgroundColor: const Color(0xFFF1E2E9)),
            const SizedBox(height: 12),
            FilledButton(onPressed: () {}, child: const Text('كمّلي التعلم')),
          ]),
        ),
      ),
    ],
  );
}

class Cat extends StatelessWidget {
  final String icon, title; final Color color;
  const Cat(this.icon, this.title, this.color, {super.key});
  @override Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(22),
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CoursePage(title: title, icon: icon))),
    child: Container(
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(22)),
      child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(icon, style: const TextStyle(fontSize: 38)), const SizedBox(height: 7),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold))
      ])),
    ),
  );
}

class CoursePage extends StatelessWidget {
  final String title, icon;
  const CoursePage({required this.title, required this.icon, super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الدورة')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: const Color(0xFFFFE4EF), borderRadius: BorderRadius.circular(28)), child: Column(children: [
        Text(icon, style: const TextStyle(fontSize: 70)), Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), const Text('تعلمي خطوة بخطوة وبأسلوب بسيط وممتع.', textAlign: TextAlign.center),
        const SizedBox(height: 18), FilledButton(onPressed: () {}, child: const Text('ابدئي الدرس'))
      ])),
      const SizedBox(height: 16),
      const Card(child: Padding(padding: EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('الدروس', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        ListTile(leading: Text('01'), title: Text('الأدوات والخامات')),
        ListTile(leading: Text('02'), title: Text('الخطوات الأساسية')),
        ListTile(leading: Text('03'), title: Text('تطبيق عملي')),
      ])))
    ]),
  );
}

class FavoritesTab extends StatelessWidget {
  const FavoritesTab({super.key});
  @override Widget build(BuildContext context) => const Center(child: Text('المفضلة 💗', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)));
}
class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override Widget build(BuildContext context) => const Center(child: Text('حسابي 🎀', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)));
}
